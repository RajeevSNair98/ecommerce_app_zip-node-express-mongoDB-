var db = require('../config/connection');
var collection = require('../config/collections');
const { ObjectId } = require('mongodb');

module.exports = {
    addProduct:(product,callback)=>{
        console.log(product);

        db.collection('products').insertOne(product).then((data)=>{
            // console.log(data.insertedId);
            callback(data.insertedId._id)
        })
    },

    getAllProducts:()=>{
        return new Promise(async(resolve,reject)=>{
            let products = await db.collection(collection.PRODUCT_COLLECTION).find().toArray()
            resolve(products)
        })
    },

//     deleteProduct:(prodId)=>{
//         return new Promise((resolve,reject)=>{
//             db.collection(collection.PRODUCT_COLLECTION).deleteOne({_id: ObjectId(prodId)}).then((response)=> {resolve(response)})
//         })
//     }

deleteProduct: (prodId) => {
    return new Promise((resolve, reject) => {
      db.collection(collection.PRODUCT_COLLECTION).deleteOne({_id:new ObjectId(prodId)}, (err, response) => {
        if (err) {
          reject(err);
        } else {
          resolve(response);
        }
      })
    })
  },

  getProductDetails: (proId)=>{
    return new Promise((resolve,reject)=>{
      db.collection(collection.PRODUCT_COLLECTION).findOne({_id:new ObjectId(proId)}).then((product)=>{
        console.log(product);
        resolve(product)
      })

    })
  },

  updateProduct: (proId, proDetails) => {
    return new Promise((resolve, reject) => {
      db.collection(collection.PRODUCT_COLLECTION).updateOne(
        { _id: new ObjectId(proId) },
        {
          $set: {
            Name: proDetails.Name,
            Description: proDetails.Description,
            Price: proDetails.Price,
            Category: proDetails.Category
          }
        }
      ).then((response) => {
        resolve();
      });
     });
      }
  
}

