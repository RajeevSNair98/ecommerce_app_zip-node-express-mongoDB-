var express = require('express');
const productHelpers = require('../helpers/product-helpers');
var router = express.Router();


/* GET users listing. */
router.get('/', function(req, res, next) {
productHelpers.getAllProducts().then((products)=>{
  res.render('admin/view-products',{admin:true, products})
})
//   let products = [
//     {
//       name:"IPHONE 11",
//       category:"Mobile",
//       description:"This is a good phone",
//       image:"https://fscl01.fonpit.de/userfiles/7043987/image/Apple/iPhone-11/AndroidPIT-iPhone11pro-front-w1400h1400.jpg"
//     },
//     {
//       name:"One plus 7T",
//       category:"Mobile",
//       description:"This is a good phone",
//       image:"https://5.imimg.com/data5/SELLER/Default/2022/3/XW/BW/XG/149641071/new-oneplus-7t-8gb-128gb-glacier-blue-500x500.jpg"
//     },
//     {
//       name:"OPPO 10X",
//       category:"Mobile",
//       description:"This is a good phone",
//       image:"https://s3b.cashify.in/gpro/uploads/2019/07/04125419/oppo-reno-10x-zoom-005.jpg"
//     },
//     {
//       name:"MI Note 9 pro",
//       category:"Mobile",
//       description:"This is a good phone",
//       image:"https://cdn.pricebaba.com/prod/images/product/mobile/71745/xiaomi-redmi-note-9-pro-raw-4611411.jpg"
//     }
//   ]
});

router.get('/add-product',function(req,res){
  res.render('admin/add-product',{admin:true})
})

router.post('/add-product',(req,res)=>{
  // console.log(req.body);
  // console.log(req.files.image);
  
  productHelpers.addProduct(req.body,(id)=>{
    let image = req.files.Image
    image.mv('./public/product-images/' + id + '.jpg',(err,done)=> {
      // console.log(id);
      if(!err){
        res.render('admin/add-product')
        
      }
    })
  })
  
})

 router.get('/delete-product/:id',(req,res)=>{
   let prodId = req.params.id
   productHelpers.deleteProduct(prodId).then((response)=>{
     res.redirect('/admin')
   })
 })


 router.get('/edit-product/:id',async(req,res)=>{
  let product =await productHelpers.getProductDetails(req.params.id)
  res.render('admin/edit-product',{product})
 })

 router.post('/edit-product/:id',(req, res)=>{
  console.log(req.params.id);
  let id =req.params.id
  productHelpers.updateProduct(id,req.body).then(()=>{
    res.redirect('/admin')
    if(req.files && req.files.Image){
    let image = req.files.Image
    image.mv('./public/product-images/' + id + '.jpg')
    }
    // else{
    //   console.log("Image error");
    // }
  })
})


module.exports = router;
