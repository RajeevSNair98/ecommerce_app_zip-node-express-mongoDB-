module.exports = {
    PRODUCT_COLLECTION:'products',
    USER_COLLECTION:'user',
    CART_COLLECTION:'cart',
    ORDER_COLLECTION:'order'
}