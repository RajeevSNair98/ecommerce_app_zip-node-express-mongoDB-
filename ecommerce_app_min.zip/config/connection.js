// const mongodb = require('mongodb');
const mongoose = require('mongoose')

const url = 'mongodb://127.0.0.1:27017/shoppingcart';
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })

const db = mongoose.connection;

db.on('error', console.error.bind(console,'connection error'));
db.once('open',function(){
    console.log("Connected to Mongodb server");
})

module.exports = db
